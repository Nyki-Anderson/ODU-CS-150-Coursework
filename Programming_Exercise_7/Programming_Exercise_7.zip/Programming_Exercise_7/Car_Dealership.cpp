/**
 * @program: Car_Dealership.cpp
 * @author: Nyki Anderson
 * @uin: 01179386
 * @lab: 28415
 * @date: March 19th, 2023
 *
 * @title: Car Dealership Report
 * @description: This program takes data from the file cars.txt and outputs the total number of cars sold at the end of each month and outputs the salesperson selling the maximum number of cars.
 */

// Declare header files and namespaces
#include <iostream>
#include <fstream> // Added fstream header
using namespace std;

int main()
{
  // Declare variables
  int cars[10];
  int sum = 0;
  int max;
  int salesPerson;

  // Declare fstream variable and open text file "cars.txt"
  ifstream inFile;
  inFile.open("cars.txt");

  // Iteratively store car sales in cars array and calculate sum of all sales
  for (int j = 0; j < 10; j++)
  {
    // Read next value into cars array
    inFile >> cars[j];

    // Add each value to sum
    sum += cars[j];
  }

  // Print sum of car sales
  cout << "The total number of cars sold = " << sum << endl;

  // Initialize max to the first value in the cars array and salesperson to 0
  max = cars[0];
  salesPerson = 0;

  // Search cars array for max cars sold
  for (int j = 1; j < 10; j++)
  {
    // If value of cars is greater than the max store value in max and store index in to salesperson
    if (max < cars[j])
    {
      max = cars[j];
      salesPerson = j;
    }
  }

  // Print the index corresponding to the salesperson (add one to give human-readable number instead of 0-9)
  cout << "The salesperson selling the maximum number of cars is salesperson "
       << salesPerson + 1 << endl;

  // Print the max cars sold and salesperson who made the sales (add one to give human-readbale number instead of 0-9)
  cout << "Salesperson " << salesPerson + 1 << " sold "
       << max << " cars last month." << endl
       << endl;

  // Close "cars.txt"
  inFile.close();

  return 0;
}