/*
Name of student source file: Right_Triangles.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: February 5th, 2023

Project Title: Is it a Right Triangle?
Project Description: This program takes user input for the length of all three sides of a triangle and outputs a message whether or not this triangle is a right triangle
*/

#include <iostream>
#include <math.h> // needed for pow function

using namespace std;

int main()
{
  // Declare variables
  int lengthA, lengthB, lengthC;

  // Prompt user to input the lengths of the three sides of a triangle
  cout << "Please enter the lengths of each side of the triangle: ";
  cin >> lengthA >> lengthB >> lengthC;

  if (pow(lengthA, 2) == pow(lengthB, 2) + pow(lengthC, 2) ||
  pow(lengthB, 2) == pow(lengthA, 2) + pow(lengthC, 2) ||
  pow(lengthC, 2) == pow(lengthB, 2) + pow(lengthA, 2)) 
    cout << "\nThis is a right triangle.";
  else
    cout << "\nThis is not a right triangle.";

  return 0;
}