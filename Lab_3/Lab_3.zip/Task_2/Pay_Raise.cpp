/*
Name of student source file: Pay_Raise.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: January 29th, 2023

Project Title: Retroactive Pay Raise
Project Description: This program calculates employees 7.6% pay increase (retroactive 6 months) based on their previous annual salary. It outputs this information to the terminal as well as writing it to a .txt file.
*/

#include <iostream> // I/O stream to read & write to terminal
#include <fstream> // file stream for file I/O
#include <iomanip> // I/O manipulators for formatting
#include <string>

using namespace std; 

// Declare constant variable for amount of raise 
const double RAISE = 0.076;

int main()
{
  // Declare all variables as doubles
  double oldAnnualSalary, newAnnualSalary, newMonthlySalary, retroSalary;
  ofstream fileOutput;

  // Prompt user to input their current (oldAnnualSalary)
  cout << endl << "Please enter your current annual salary: $";
  cin >> oldAnnualSalary;
  cout << endl << endl;

  // Calculate new annual salary
  newAnnualSalary = oldAnnualSalary * (1 + RAISE);

  // Calculate new monthly salary
  newMonthlySalary = newAnnualSalary / 12;

  // Calculate retroactive salary due (minus the amount they were already paid for the last 6 months)
  retroSalary = (newAnnualSalary / 2) - (oldAnnualSalary / 2);

  // Output all calculated amounts with two decimal places (currency must be formatted $__.__)
  cout << fixed << showpoint << setprecision(2);
  cout << "New annual salary: $" << newAnnualSalary << endl;
  cout << "New monthly salary: $" << newMonthlySalary << endl;
  cout << "Retroactive salary due: $" << retroSalary << endl;

  // Open file associated with ofstream variable and write a copy of the salary report to an empty file
  fileOutput.open("Output.txt");

  // Message that file is being written
  cout << endl << "Writing output to file..." << endl;

  fileOutput << fixed << showpoint << setprecision(2);
  fileOutput << "New annual salary: $" << newAnnualSalary << endl;
  fileOutput << "New montly salary: $" << newMonthlySalary << endl;
  fileOutput << "Retroactive salary due: $" << retroSalary << endl;

  cout << endl << "Output file is complete." << endl;

  fileOutput.close();
  return 0;
}