/*
Name of student source file: Weight_Conversion.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: January 29th, 2023

Project Title: Weight Conversion 
Project Description: This program prompts the user to enter the weight of a person in kilograms and outputs the equivalent weight in pounds (rounded to two decimal places).
*/

#include <iostream>
#include <iomanip>

using namespace std;

// Declare constant for conversion from kilos to pounds
const double KILO_TO_POUNDS = 2.2;

int main()
{
  // Declare variables for weightKilos and weightPounds
  double weightKilos, weightPounds;

  // Prompt user to enter weight in kilos
  cout << "Please enter the weight in kilograms: ";
  cin >> weightKilos;

  // Calculate the conversion from kilos to pounds
  weightPounds = weightKilos * KILO_TO_POUNDS;

  // Manipulate the output of the weights so they display only two decimal places and do not display in scientific mode
  cout << endl << fixed << showpoint << setprecision(2);
  cout << "You entered " << weightKilos << " kilos." << endl;
  cout << "The equivalent weight in pounds is = " << weightPounds << " lbs.";
} 