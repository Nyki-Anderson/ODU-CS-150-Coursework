/*
Name of student source file: Ice_Skating.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: February 12th, 2023

Project Title: Cost of Admission at Ice Skating Rink
Project Description: This program takes the number of entrants in each age group and calculates the total cost of admision.
*/

#include <iostream>
#include <iomanip>

using namespace std;

// Declare constants
const double ADMISSION_6_UNDER = 8.50;
const double ADMISSION_7_OLDER = 10.50;
const double ADMISSION_ADULT = 12.00;
const double ADMISSION_SENIOR = 9.50;
const double TAX = 0.10;

int main()
{
  // Declare variables
  int numChildren6Under, numChildren7Older, numAdult, numSenior;
  double costAdmission;

  // Prompt user to input number of entrants in each age group
  cout << "Enter the number of children 6 and younger: ";
  cin >> numChildren6Under;
  cout << "Enter the number of children 7 and older: ";
  cin >> numChildren7Older;
  cout << "Enter the number of adults: ";
  cin >> numAdult;
  cout << "Enter the number of seniors: ";
  cin >> numSenior;
  cout << endl;

  // Print Nice Receipt Header
  cout << endl << "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*" << endl << endl;
  cout << "     " << setw(40) << setfill('*') << "     " << endl;
  cout << "     " << setfill(' ') << "*  Welcome to ICE-SKATING Center  *" << "     " << endl;
  cout << "     " << setw(40) << setfill('*') << "     " << endl << endl;

  // Output users inputs for each age group
  cout << left << setfill('.') << setw(40) << "The number of children 6 and under is " << right << setfill('.') << setw(10) << numChildren6Under << endl;

  cout << left << setfill('.') << setw(40) << "The number of children 7 and older is " << right << setfill('.') << setw(10) << numChildren7Older << endl;

  cout << left << setfill('.') << setw(40) << "The number of adults is " << right << setfill('.') << setw(10) << numAdult << endl;

  cout << left << setfill('.') << setw(40) << "The number of seniors is " << right << setfill('.') << setw(10) << numSenior << endl;

  // Horizontal line for formatting
  cout << endl << "-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*" << endl << endl;

  // Calculate the subtotal
  costAdmission = (numChildren6Under * ADMISSION_6_UNDER) + (numChildren7Older * ADMISSION_7_OLDER) + (numAdult * ADMISSION_ADULT) + (numSenior * ADMISSION_SENIOR);

  // Format floating points to display 2 decimals
  cout << fixed << showpoint << setprecision(2);

  // Output subtotal
  cout << left << setfill('.') << setw(15) << "Subtotal " << right << setw(30) << setfill('.') << "$" << costAdmission << endl;

  // Output tax
  cout << left << setfill('.') << setw(15) << "Tax " << right << setw(30) << setfill('.') << "$" << (costAdmission * TAX) << endl;

  // Output total
  cout << left << setfill('.') << setw(15) << "Total " << right << setw(30) << setfill('.') << "$" << (costAdmission * TAX + costAdmission) << endl;
  
  return 0;
}