inData >> classData[i].studentName.first >> classData[i].studentName.last >> classData[i].testScore;

    inData.ignore(100, '\n');