/*
Name of student source file: Divisible_7.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: February 19th, 2023

Project Title: Sum all Numbers Divisible by 7
Project Description: This program adds all the numbers between 1 and 100 that are divisible by 7.
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  // Declare variables
  int i, sum = 0;

  // Print program header
  cout << "The numbers divisible by 7 (between 1 and 100): " << endl;
  cout << setw(50) << setfill('-') << " " << endl;

  // Iterate through all numbers 1 through 100
  for (i = 1; i <= 100; i++)
  {
    // Check if the current number is divisible by 7
    if (i % 7 == 0)
    {
      // Print current number divisible by 7
      cout << i << endl;
      // Add the current number to sum
      sum += i;
    }
  }

  // Print the sum of all numbers divisible by 7
  cout << "The sum of all numbers divisible by 7 (between 1 and 100) = " << sum;
}