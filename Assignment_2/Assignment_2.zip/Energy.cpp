/*
Name of student source file: Energy.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: January 29th, 2023

Project Title: Calculating the Energy it takes to Increase Temperature of Water
Project Description: This program takes three pieces of user input: (1) the weight of water in kilograms, (2) the initial temperature of the water in degrees Celsius, and (3) the final temperature of the water, also in degrees Celsius. It then calculates the energy (in joules) required to raise the temperature of the water. It then displays the value of energy.
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
  // Declare all variables
  double weightOfWater, initialTemp, finalTemp, energyQ;
  string border = "*******************************";
  string header = "*      Calculating Energy     *";

  // Format the header and border design for title
  cout << border << endl;
  cout << header << endl;
  cout << border << endl << endl;

  // Request user input for weight of water and initial and final temperature in celsius
  cout << "Enter the amount of water in kilograms: ";
  cin >> weightOfWater;
  cout << "Enter the initial temperature in Celsius: ";
  cin >> initialTemp;
  cout << "Enter the final temperature in Celsius: ";
  cin >> finalTemp;

  // Calculate energy required to heat water to desired final temperature
  energyQ = weightOfWater * (finalTemp - initialTemp) * 4184;

  // Display calculated energy in joules
  cout << endl << "The energy needed is: " << energyQ << " joules.";

  return 0;
}