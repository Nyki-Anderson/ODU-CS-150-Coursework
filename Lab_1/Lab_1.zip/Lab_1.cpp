// Name of student source file: Nyki_Anderson_Lab1.cpp
// Student Name: Nyki Anderson
// Student UIN: 01179386
// Date: January 17th, 2023

# include <iostream>

using namespace std;

int main()
{
    cout << "Name of student source file: Nyki_Anderson_Lab1.cpp" << endl;

    cout << "Student Name: Nyki Anderson" << endl;

    cout << "Student UIN: 01179386" << endl;

    cout << "Date: January 17th, 2023" << endl;

    cout << "Lab CRN: 28415" << endl;

    return 0;
}

