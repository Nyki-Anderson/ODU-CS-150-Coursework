/*
Name of student source file: Fibonacci.cpp
Student Name: Nyki Anderson
Student UIN: 01179386
Lab CRN: 28415
Date: February 12th, 2023

Project Title: Find the Nth Fibonnaci Number
Project Description: This program takes user input for the first two in the fibonnaci sequence. Then the user inputs an nth fibonacci number they wish to calculate and this value is output to the screen.
*/

#include <iostream>

using namespace std;

int main()
{
  // Declare variables
  int previous1, previous2, current, counter, nthFibonacci;

  // Prompt user for the first two Fibonacci numbers (previous1 and previous2)
  cout << "Enter the first two Fibonacci numbers: ";

  // Store first two Fibonacci numbers (previous1 and previous2)
  cin >> previous1 >> previous2;
  cout << endl;

  // Output the first two Fibonacci numbers
  cout << "The first two Fibonacci numbers are: " << previous1 << " and " << previous2 << endl;

  // Prompt user for the position of the desired Fibonacci number
  cout << "Enter the position of the desired Fibonacci number: ";

  // Store the desired Fibonacci number
  cin >> nthFibonacci;
  cout << endl;

  switch (nthFibonacci)
  {
    case 1:
      current = previous1;
      break;
    case 2:
      current = previous2;
      break;
    default:
      counter = 3;

      // If counter is less than nthFibonacci continue the Fibonacci sequence
      while (counter <= nthFibonacci)
      {
        current = previous2 + previous1;
        previous1 = previous2;
        previous2 = current;
        counter++;
      }
      break;
  }
  // Output the nth Fibonacci number
  cout << "The Fibonacci number at postion " << nthFibonacci << " is " << current << endl;

  return 0;
}