/**
 * @program: History_Class.cpp
 * @author: Nyki Anderson
 * @uin: 01179386
 * @lab: 28415
 * @date: April 9, 2023
 *
 * @title: Grading a History Exam
 * @description: This program reads a file named input.txt that contains the correct answers for a histroy exam and the student IDs with their answers for the exam. It then calculates each student's score and letter grade. The results are printed with the following information: student ID, student's responses, their score, and their grade.
 */

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
using namespace std;

class StudentClass
{
public:
  string ID;
  char answers[21];
  int score;
  char grade;
};

void read_file(ifstream &inData, StudentClass *classExam, char *examKey);
void print_header(char *examKey);
void grade_exams(StudentClass *classExam, const char *examKey);
void assign_letter(StudentClass *classExam);
void print_results(StudentClass *classExam);

int main()
{
  StudentClass *classExam;
  classExam = new StudentClass[4];

  char *examKey;
  examKey = new char[20];

  ifstream inData;

  read_file(inData, classExam, examKey);
  print_header(examKey);
  grade_exams(classExam, examKey);
  assign_letter(classExam);
  print_results(classExam);

  delete[] classExam;
  delete[] examKey;
  return 0;
}

void read_file(ifstream &inData, StudentClass *classExam, char *examKey)
{
  inData.open("input.txt");

  for (int k = 0; k < 20; k++)
    inData.get(examKey[k]);

  inData.ignore(100, '\n');

  for (int i = 0; i < 4; i++)
  {
    inData >> classExam->ID;

    for (int j = 0; j < 21; j++)
    {
      inData.get(classExam->answers[j]);
    }
    classExam++;
    inData.ignore(100, '\n');
  }

  inData.close();
}

void print_header(char *examKey)
{
  cout << "Processing Data" << endl;

  for (int i = 0; i < 21; i++)
  {
    cout << examKey[i];
  }

  cout << endl
       << endl;

  cout << setw(15) << left << "Student Name" << setw(25) << left << "Student Answers" << setw(10) << left << "Score" << setw(10) << left << "Grade" << endl;
}

void grade_exams(StudentClass *classExam, const char examKey[])
{
  int score;

  for (int j = 0; j < 4; j++)
  {
    score = 0;

    for (int i = 0; i < 21; i++)
    {
      if ((classExam->answers[i]) == examKey[i])
        score += 2;
      else if ((classExam->answers[i]) == ' ')
        score += 0;
      else
        score -= 1;
    }

    classExam[j].score = score;
    classExam[j].grade = ' ';

    classExam++;
  }
}
void assign_letter(StudentClass *classExam)
{
  double percent;

  for (int i = 0; i < 4; i++)
  {
    percent = 0.0;

    percent = classExam->score / 40;

    if (percent >= 90.0)
      classExam[i].grade = 'A';
    else if (percent >= 80.0)
      classExam[i].grade = 'B';
    else if (percent >= 70.0)
      classExam->grade = 'C';
    else if (percent >= 60.0)
      classExam[i].grade = 'D';
    else
      classExam[i].grade = 'F';
  }
}
void print_results(StudentClass *classExam)
{
  string answersString;

  for (int i = 0; i < 4; i++)
  {
    answersString = "";

    for (int j = 0; j < 21; j++)
    {
      answersString += classExam[i].answers[j];
    }

    cout << setw(15) << left << classExam[i].ID << setw(25) << left << answersString << setw(10) << left << classExam[i].score << setw(10) << left << classExam[i].grade << endl;
  }
}
